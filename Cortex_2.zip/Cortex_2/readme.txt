regT_total_30:
motion regressed out individual network timecourse data (48 participants/ 30 components each/ MID1 & 2)

EV_task:
Task timecourse data (gain anticipation) 